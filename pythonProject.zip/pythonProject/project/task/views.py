from django.shortcuts import render

def error(request):
    pass
